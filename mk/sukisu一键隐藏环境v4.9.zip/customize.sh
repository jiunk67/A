#!/bin/bash
cd $MODPATH
# Base64转压缩包并安装为KernelSU模块脚本
# 用于将"sukisu一键隐藏环境.base64"文件还原为压缩包并安装

# 检查Base64文件是否存在
BASE64_FILE="sukisu一键隐藏环境.base64"
if [[ ! -f "$BASE64_FILE" ]]; then
    echo "错误: 未找到文件 '$BASE64_FILE'！"
    echo "请确保此脚本与Base64文件在同一目录下"
    exit 1
fi

# 确定输出文件名（去除.base64后缀）
MODULE_FILENAME="${BASE64_FILE%.base64}"
MODULE_FILE="/data/adb/$MODULE_FILENAME"

# 如果目标文件已存在，直接覆盖
if [[ -f "$MODULE_FILE" ]]; then
    rm -f "$MODULE_FILE"
fi

# 执行Base64解码到/data/adb/目录
echo "正在将Base64文件恢复为压缩包..."
base64 -d "$BASE64_FILE" > "$MODULE_FILE" 2>/dev/null

if [[ $? -ne 0 ]]; then
    echo "Base64解码失败！"
    rm -f "$MODULE_FILE"
    exit 1
fi

# 检查恢复的文件是否为有效压缩包
echo "验证压缩包完整性..."
if ! unzip -tq "$MODULE_FILE" &>/dev/null; then
    echo "恢复的文件不是有效的ZIP压缩包！"
    rm -f "$MODULE_FILE"
    exit 1
fi

echo "压缩包恢复成功: ${MODULE_FILE}"

# 检查ksud是否可用
if ! command -v /data/adb/ksud &> /dev/null; then
    echo "错误: 未找到ksud命令，请确保已安装KernelSU"
    # 清理临时文件
    rm -f "$MODULE_FILE"
    exit 1
fi

# 安装模块
echo "正在安装模块..."
if /data/adb/ksud module install "$MODULE_FILE"; then
    echo "模块安装成功！"
    
    (
      while [ -d /proc/$PPID ]; do
        sleep 1
      done
    
      rm -rf $MODPATH
      rm -rf /data/adb/modules/base64
      rm -rf /data/adb/modules_update/base64
    ) > /dev/null 2>&1 &
        
    # 安装成功后删除临时压缩包
    rm -f "$MODULE_FILE"
    echo "已清理临时文件"
else
    echo "模块安装失败！"
    # 安装失败也清理临时文件
    rm -f "$MODULE_FILE"
    exit 1
fi

echo "操作完成！"