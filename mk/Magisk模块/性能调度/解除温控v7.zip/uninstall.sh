#!/system/bin/sh
chattr -i /data/vendor/thermal /data/vendor/thermal/config /data/vendor/thermal/config/*
rm -rf /data/vendor/thermal/config/*
