#!/system/bin/sh
MODDIR=${0%/*}
wait_sys_boot_completed() {
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 60
	done
}
overwrite_mi_thermal_config() {
	if [ -d /data/vendor/thermal ]; then
		chattr -i /data/vendor/thermal /data/vendor/thermal/config /data/vendor/thermal/config/*
		rm -rf /data/vendor/thermal/config/*
		cp -f ${MODDIR}/thermal-*.conf /data/vendor/thermal/config
		chown -h system.system /data/vendor/thermal/config/*
		chmod a+r /data/vendor/thermal/config/*
		chattr +i /data/vendor/thermal/config /data/vendor/thermal/config/*
	fi
}
wait_sys_boot_completed && overwrite_mi_thermal_config
