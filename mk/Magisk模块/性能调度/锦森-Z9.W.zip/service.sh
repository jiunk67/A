#!/system/bin/sh
CONFIG_PATH="/data/jinsen/config.conf"

# 开机完成后等待
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# 主要功能函数
main() {
    # 复制热管理相关配置文件
    cp /vendor/etc/thermal*.conf /data/vendor/thermal/config/
    
    # 如果模块目录下的配置文件存在，则复制至指定位置
    if [ -d "$MODDIR/config" ]; then
        cp "$MODDIR/config/*" /data/vendor/thermal/config/
    fi
    
    # 设置目录权限
    chmod 771 /data/vendor/thermal/config/*

    # 清理缓存文件
    rm -f /cache/miui-thermal/*

    # 禁用无关服务和应用
    pm disable com.miui.powerkeeper/.feedbackcontrol.abnormallog.ThermalLogService
    stop miuibooster
    stop mi_thermald
}

# 官方模式操作
official_mode() {
    pm enable com.xiaomi.joyose
    am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
    pm enable com.xiaomi.joyose/.cloud.LocalCtrlActivity # 移除重复行
    pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
}

# 非官方模式操作
unofficial_mode() {
    pm disable com.xiaomi.joyose
    pm disable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
}

# 根据配置文件内容选择执行模式
if grep -qE '^ON' "$CONFIG_PATH"; then
    unofficial_mode
else
    official_mode
fi
mtk_dcs() [
# 获取设备SoC信息
soc_platform=$(getprop ro.board.platform)
contains_mt=$(echo "$soc_platform" | grep -c '^mt')

if [ $contains_mt -gt 0 ]; then
    echo "当前设备为联发科处理器，执行DCS关闭操作" >> /cache/magisk.log

    # DCS路径
    no_dcs=/sys/kernel/ged/hal/dcs_mode

    # 尝试卸载DCS
    if umount $no_dcs; then
        echo "DCS路径已成功卸载: $no_dcs" >> /cache/magisk.log
    else
        echo "无法卸载DCS路径: $no_dcs" >> /cache/magisk.log
        # 可能的错误处理逻辑
    fi

    # 改变权限
    if chmod 644 $no_dcs; then
        echo "DCS文件权限已更改" >> /cache/magisk.log
    else
        echo "无法更改DCS文件权限" >> /cache/magisk.log
        # 可能的错误处理逻辑
    fi

    # 关闭DCS
    echo 0 > $no_dcs

    # 检查缓存文件是否存在
    if [[ ! -f /cache/dcs_mode ]]; then
        # 设置权限
        if chmod 444 $no_dcs; then
            echo "DCS文件权限设置为只读" >> /cache/magisk.log
        else
            echo "无法设置DCS文件为只读" >> /cache/magisk.log
            # 可能的错误处理逻辑
        fi

        # 写入缓存文件
        if echo '0' > /cache/dcs_mode; then
            echo "已创建并写入缓存文件: /cache/dcs_mode" >> /cache/magisk.log
        else
            echo "无法写入缓存文件" >> /cache/magisk.log
            # 可能的错误处理逻辑
        fi

        # 设置缓存文件为不可变
        if chattr +i /cache/dcs_mode; then
            echo "已将缓存文件设置为不可变" >> /cache/magisk.log
        else
            echo "无法将缓存文件设置为不可变" >> /cache/magisk.log
            # 可能的错误处理逻辑
        fi
    fi

    # 重新挂载DCS
    if mount --rbind /cache/dcs_mode $no_dcs; then
        echo "DCS已重新挂载" >> /cache/magisk.log
    else
        echo "无法重新挂载DCS" >> /cache/magisk.log
        # 可能的错误处理逻辑
    fi
else
    echo "你的设备为骁龙处理器已关闭联发科优化" | tee -a /cache/magisk.log
fi
]
# 执行主函数
main
# 执行DCS
mtk_dcs