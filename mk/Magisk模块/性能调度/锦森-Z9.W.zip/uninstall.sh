#!/system/bin/sh
chattr -i /data/system/mcd/df
chattr -i /cache/dcs_mode
pm clear com.xiaomi.joyose
pm clear com.xiaomi.powerchecker
am force-stop com.xiaomi.joyose
rm -f /data/cache/miui-thermal/*
rm -f /data/vendor/thermal/*
rm -f /data/jinsen/
rm -f /data/system/mcd/df
rm -f /cache/dcs_mode
mkdir -p /vendor/etc/thermal/config
cp /vendor/etc/thermal*.conf /data/vendor/thermal/config/
pm enable com.xiaomi.joyose