#!/system/bin/sh
MODDIR=${0%/*}
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
}

store="/data/jinsen/config.conf"
config="#修改后需重启手机
#ON第三方
#OFF官方
"
  ui_print "*******************************"
  ui_print "刷入中"
  ui_print "你下一个云控何必是云控"
  ui_print "刷入成功后请你重启手机"
  ui_print "*******************************"
  
  pm clear com.xiaomi.powerchecker
  pm clear com.xiaomi.joyose
  mkdir -p /data/jinsen/
  chattr -i /data/system/mcd/df
  rm -f /data/system/mcd/df
  echo '' > /data/system/mcd/df
  chattr +i /data/system/mcd/df
  
    ui_print "*******************************"
    ui_print "不是刷入失败都无需反馈给作者" 
    ui_print "*******************************"
    
    ui_print "*******************************"
    ui_print "调度确认"
    ui_print "第三方选择音量上键"
    ui_print "官方选择音量下键"
    ui_print "改变调度请查看:/data/jinsen/config.conf"
    ui_print "*******************************"
        key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo "启动第三方调度方案"
    echo "$config
ON" > $store
        ;;
        *)
            echo "启动官方调度方案"
            echo "$config
OFF" > $store
            esac

set_permissions