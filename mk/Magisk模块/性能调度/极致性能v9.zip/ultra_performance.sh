#!/system/bin/sh
MODDIR=${0%/*}
find_sys_scaling_governor() {
	for SYS_SCALING_GOVERNOR in $(ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor 2>/dev/null); do
		if [ -f $SYS_SCALING_GOVERNOR ]; then
			return 0
		fi
	done
	exit 1
}
set_default_scaling_governor() {
	local WAITING_TIMES=60
	while [ $WAITING_TIMES -gt 0 ]; do
		if [ $(cat $SYS_SCALING_GOVERNOR) ==  "performance" ]; then
			sleep 1
			local WAITING_TIMES=$(($WAITING_TIMES-1))
		else
			DEFAULT_CPU_SCALING_GOVERNOR=$(cat $SYS_SCALING_GOVERNOR)
			local WAITING_TIMES=0
		fi
	done
	if [ -z $DEFAULT_CPU_SCALING_GOVERNOR ]; then
		SCALING_AVAILABLE_GOVERNORS=$(cat ${SYS_SCALING_GOVERNOR%/*}/scaling_available_governors)
		if [[ $SCALING_AVAILABLE_GOVERNORS == *"walt"* ]]; then
			DEFAULT_CPU_SCALING_GOVERNOR="walt"
		elif [[ $SCALING_AVAILABLE_GOVERNORS == *"schedutil"* ]]; then
			DEFAULT_CPU_SCALING_GOVERNOR="schedutil"
		elif [[ $SCALING_AVAILABLE_GOVERNORS == *"ondemand"* ]]; then
			DEFAULT_CPU_SCALING_GOVERNOR="ondemand"
		elif [[ $SCALING_AVAILABLE_GOVERNORS == *"conservative"* ]]; then
			DEFAULT_CPU_SCALING_GOVERNOR="conservative"
		elif [[ $SCALING_AVAILABLE_GOVERNORS == *"powersave"* ]]; then
			DEFAULT_CPU_SCALING_GOVERNOR="powersave"
		else
			exit 1
		fi
	fi
}
reset_qcom_lpm() {
	local TARGET_PATH=$1
	local TARGET_VALUE=$2
	local WRITE_PERMISSION=$3
	if [ $(cat $TARGET_PATH) != "$TARGET_VALUE" ]; then
		chmod u+w $TARGET_PATH
		echo "$TARGET_VALUE" > $TARGET_PATH
		if [ $WRITE_PERMISSION == "N" ]; then
			chmod a-w $TARGET_PATH
		elif [ $WRITE_PERMISSION == "Y" ]; then
			chmod u+w $TARGET_PATH
		fi
	fi
}
performance_mode() {
	for CPU_ONLINE in $(ls /sys/devices/system/cpu/cpu*/online 2>/dev/null); do
		if [ $(cat $CPU_ONLINE) == "0" ]; then
			echo "1" > $CPU_ONLINE
		fi
	done
	for CPU_SCALING_GOVERNOR in $(ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor 2>/dev/null); do
		if [[ $(cat ${CPU_SCALING_GOVERNOR%/*}/scaling_available_governors) == *"performance"* ]]; then
			echo "performance" > $CPU_SCALING_GOVERNOR
		fi
	done
	if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
		reset_qcom_lpm  "/sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled" "1" "N"
	elif [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
		reset_qcom_lpm  "/sys/module/lpm_levels/parameters/sleep_disabled" "Y" "N"
	fi
	if [ $(cat /sys/devices/system/cpu/c1dcvs/enable_c1dcvs 2>/dev/null) == "1" ]; then
		echo "0" > /sys/devices/system/cpu/c1dcvs/enable_c1dcvs
	fi
	for BUS_DCVS_BOOST_FREQ in $(ls /sys/devices/system/cpu/bus_dcvs/*/boost_freq 2>/dev/null); do
		if [ -f ${BUS_DCVS_BOOST_FREQ%/*}/hw_max_freq ] && [ -f ${BUS_DCVS_BOOST_FREQ%/*}/hw_min_freq ]; then
			echo "$(cat ${BUS_DCVS_BOOST_FREQ%/*}/hw_max_freq)" > $BUS_DCVS_BOOST_FREQ
		fi
	done
	for CPUFREQ_POLICY in $(ls -d /sys/devices/system/cpu/cpufreq/policy* 2>/dev/null); do
		if [ -f ${CPUFREQ_POLICY}/cpuinfo_max_freq ] && [ -f ${CPUFREQ_POLICY}/scaling_min_freq ]; then
			echo "$(cat ${CPUFREQ_POLICY}/cpuinfo_max_freq)" > ${CPUFREQ_POLICY}/scaling_min_freq
		fi
	done
}
balanced_mode() {
	for CPU_ONLINE in $(ls /sys/devices/system/cpu/cpu*/online 2>/dev/null); do
		if [ $(cat $CPU_ONLINE) == "0" ]; then
			echo "1" > $CPU_ONLINE
		fi
	done
	for CPU_SCALING_GOVERNOR in $(ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor 2>/dev/null); do
		if [[ $(cat ${CPU_SCALING_GOVERNOR%/*}/scaling_available_governors) == *"$DEFAULT_CPU_SCALING_GOVERNOR"* ]]; then
			echo "$DEFAULT_CPU_SCALING_GOVERNOR" > $CPU_SCALING_GOVERNOR
		fi
	done
	if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
		reset_qcom_lpm  "/sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled" "0" "Y"
	elif [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
		reset_qcom_lpm  "/sys/module/lpm_levels/parameters/sleep_disabled" "N" "Y"
	fi
	if [ $(cat /sys/devices/system/cpu/c1dcvs/enable_c1dcvs 2>/dev/null) == "0" ]; then
		echo "1" > /sys/devices/system/cpu/c1dcvs/enable_c1dcvs
	fi
	for BUS_DCVS_BOOST_FREQ in $(ls /sys/devices/system/cpu/bus_dcvs/*/boost_freq 2>/dev/null); do
		if [ -f ${BUS_DCVS_BOOST_FREQ%/*}/hw_max_freq ] && [ -f ${BUS_DCVS_BOOST_FREQ%/*}/hw_min_freq ]; then
			echo "$(cat ${BUS_DCVS_BOOST_FREQ%/*}/hw_min_freq)" > $BUS_DCVS_BOOST_FREQ
		fi
	done
	for CPUFREQ_POLICY in $(ls -d /sys/devices/system/cpu/cpufreq/policy* 2>/dev/null); do
		if [ -f ${CPUFREQ_POLICY}/cpuinfo_min_freq ] && [ -f ${CPUFREQ_POLICY}/scaling_min_freq ]; then
			echo "$(cat ${CPUFREQ_POLICY}/cpuinfo_min_freq)" > ${CPUFREQ_POLICY}/scaling_min_freq
		fi
	done
}
find_sys_scaling_governor && set_default_scaling_governor
while true; do
	sleep 1
	[ $(settings get system speed_mode) == 0 ] && settings put system speed_mode 1
	if [ $(cat /sys/class/power_supply/battery/status) != "Discharging" ]; then
		[ ! -f ${MODDIR}/disable ] && [ $(getprop sutoliu.powered_on_performance_enhancements) ==  "Y" ] && performance_mode
		while [ $(cat /sys/class/power_supply/battery/status) != "Discharging" ]; do
			sleep 2
		done
	else
		balanced_mode
		while [ $(cat /sys/class/power_supply/battery/status) == "Discharging" ]; do
			sleep 5
		done
	fi
done
