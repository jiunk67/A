#!/system/bin/sh
# 等待系统完全启动
until [ $(getprop sys.boot_completed) -eq 1 ]; do
    sleep 5
done

# 配置项（根据需求修改）
TARGET_APP="com.tencent.tmgp.pubgmhd"  # 要监测的系统应用包名（示例：设置）
EXEC_FILE="/data/local/tmp/1.sh"      # 要执行的文件绝对路径
FLAG_FILE="/data/local/tmp/app_monitor_flag"  # 防重复执行标记

# 后台循环监测
while true; do
    # 检测目标应用是否运行
    if pgrep -f "$TARGET_APP" > /dev/null; then
        # 标记文件不存在时执行脚本
        if [ ! -f "$FLAG_FILE" ]; then
            # 执行指定文件（需确保文件有执行权限）
            if [ -f "$EXEC_FILE" ]; then
                chmod +x "$EXEC_FILE"
                sh "$EXEC_FILE" &
                # 创建标记文件，避免重复执行
                touch "$FLAG_FILE"
            fi
        fi
    else
        # 应用退出时删除标记文件
        if [ -f "$FLAG_FILE" ]; then
            rm -f "$FLAG_FILE"
        fi
    fi
    sleep 5  # 降低资源占用
done &  # 后台运行循环