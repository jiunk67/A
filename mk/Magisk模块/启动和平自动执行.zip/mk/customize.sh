#!/system/bin/sh
# 给service.sh添加执行权限
chmod +x $MODPATH/service.sh
# 创建日志目录（可选）
mkdir -p /data/local/tmp/appmonitor_log
