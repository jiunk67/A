#!/system/bin/sh

sleep 2m

Amend() {
	chmod 644 $2
	echo $1 > $2
}

Cpu_Max() {
	Cpu=${Cpus}$1/cpufreq/scaling_
	Amend $Num ${Cpu}max_freq
	Amend $Num ${Cpu}min_freq
	Amend performance ${Cpu}governor
}
Cpus=/sys/devices/system/cpu/cpu
for i in `find ${Cpus}freq -iname 'policy*' -type d`
do
	Soc=`echo $i | tr -cd [0-9]`
	Num=`cat $i/cpuinfo_max_freq`
	Max_Num+="$Num\n"
	Cpu_Max $Soc
	case $Soc in
		0)
			Cpu_Max 1
			;;
		2)
			 Cpu_Max 3
			;;
		5)
			Cpu_Max 4
			;;
		7)
			Cpu_Max 6
			;;
		*)
	esac
done
Num=`echo "$Max_Num" | sort -rn | head -n 1`
Cpu=${Cpus}freq/policy7/scaling_
Amend $Num ${Cpu}max_freq
Amend $Num ${Cpu}min_freq
Amend performance ${Cpu}governor

Gpu=/sys/class/kgsl/kgsl-3d0
Gpu_List="$Gpu/min_pwrlevel
$Gpu/max_pwrlevel
$Gpu/default_pwrlevel"
for i in $Gpu_list
do
	Amend 0 $i
done
Gpus=$Gpu/devfreq
Amend performance $Gpus/governor
Gpu_List="$Gpus/max_freq
$Gpus/min_freq
$Gpu/max_clock_mhz
$Gpu/max_gpuclk
$Gpu/min_clock_mhz"
for i in $Gpu_list
do
	Amend `cat $Gpu/gpu_available_frequencies | awk '{print $1}'` $i
done

Amend 0-7 /dev/cpuset/foreground/cpus
Amend 0-7 /dev/cpuset/foreground/boost/cpus
Amend 0-7 /dev/cpuset/top-app/cpus
Amend 0-7 /dev/cpuset/background/cpus
Amend 0-7 /dev/cpuset/system-background/cpus
Amend 0-7 /dev/cpuset/camera-daemon/cpus
Amend 2048 /sys/block/sda/queue/read_ahead_kb
Amend 1024 /sys/block/sda/queue/nr_requests
Amend deadline /sys/block/sda/queue/scheduler

service call SurfaceFlinger 1008 i32 1

Amend 180000 /sys/class/thermal/thermal_zone24/trip_point_1_temp
Amend 180000 /sys/class/thermal/thermal_zone25/trip_point_0_temp

rm -rf /data/vendor/thermal/config
Hw_1=/data/cache/thermal
touch $Hw_1
for i in `find -L /system -iname *thermal* -type f | grep -v hardware | grep -v @ | grep -v .so`
do
	Hw_2=${i##*/}
	Hw_2=${Hw_2##*.}
	[[ $Hw_2 = xml || $Hw_2 = conf || $Hw_2 = rc ]] && {
		umount $i
		mount --bind $Hw_1 $i
	}
done

Amend 260 /sys/class/power_supply/bms/temp
Amend 260 /sys/class/power_supply/battery/temp
Amend Good /sys/class/power_supply/battery/health

rm -rf /data/vendor/thermal/config/*
dumpsys battery reset
Disable_List='com.xiaomi.NetworkBoost
com.miui.analytics
com.xiaomi.powerchecker
com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
com.miui.securitycenter
com.miui.powercenter
com.miui.gamebooster
com.miui.hybrid.settings
com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose
com.miui.daemon'
for i in $Disable_List
do
	pm clear $i
	pm disable $i
done